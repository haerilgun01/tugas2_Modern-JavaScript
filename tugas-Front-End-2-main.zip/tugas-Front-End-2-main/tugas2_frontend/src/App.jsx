import './App.css'
import Todo from './pages/Todo'

function App() {

  return (
    <>
      <h2>Pertemuan-2</h2>
      <Todo />
    </>
  )
}

export default App
